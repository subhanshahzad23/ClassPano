"use strict";
(() => {
  // src/core/adapters/types.ts
  var emptyResult = (pageKind) => ({ pageKind, assignments: [], grades: [], announcements: [], events: [], warnings: [] });

  // src/core/adapters/blackbaud.ts
  var BB_SELECTORS = {
    assignmentRows: "#assignment-center-assignment-items tbody tr[data-assignment-id]",
    cell: (heading) => `td[data-heading="${heading}"]`,
    title: ".wbp-title",
    points: ".wbp-points",
    details: ".wbp-desc",
    score: ".wbp-score",
    status: ".wbp-status",
    calendarItems: ".wbp-calendar .wbp-cal-item[data-assignment-id]",
    calendarEvents: ".wbp-calendar .wbp-cal-event[data-event-id]",
    progressRows: ".wbp-progress .wbp-progress-row[data-section-id]",
    term: "[data-term]",
    bulletins: ".wbp-bulletins .wbp-bulletin",
    classPage: '[data-portal-page="class"]',
    className: ".wbp-classname",
    teacher: ".wbp-teacher"
  };
  var HOSTS = [/\.myschoolapp\.com$/i, /^portal\.westbrook-academy\.test$/i];
  var text = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  function hostOf(url) {
    try {
      return new URL(url).hostname;
    } catch {
      return "";
    }
  }
  var blackbaudAdapter = {
    id: "blackbaud",
    name: "Blackbaud Education Management",
    version: "0.4.0",
    status: "ready",
    matches(ctx) {
      const host = hostOf(ctx.url);
      if (HOSTS.some((re) => re.test(host))) return true;
      return !!ctx.root.querySelector("[data-portal-shell='education-management']");
    },
    detectPage(ctx) {
      const r = ctx.root;
      if (r.querySelector(BB_SELECTORS.assignmentRows)) return "assignments";
      if (r.querySelector(".wbp-calendar")) return "schedule";
      if (r.querySelector(".wbp-progress")) return "progress";
      if (r.querySelector(BB_SELECTORS.classPage)) return "class";
      return "unknown";
    },
    async extract(ctx) {
      const kind = this.detectPage(ctx);
      const out = emptyResult(kind);
      const r = ctx.root;
      if (kind === "assignments") {
        r.querySelectorAll(BB_SELECTORS.assignmentRows).forEach((row) => {
          const cell = (h) => row.querySelector(BB_SELECTORS.cell(h));
          const details = cell("Details");
          const title = text(details?.querySelector(BB_SELECTORS.title));
          if (!title) {
            out.warnings.push(`Row ${row.getAttribute("data-assignment-id")} has no title \u2014 skipped.`);
            return;
          }
          out.assignments.push({
            externalId: row.getAttribute("data-assignment-id") ?? void 0,
            courseExternalId: row.getAttribute("data-section-id") ?? void 0,
            courseName: text(cell("Class")),
            typeText: text(cell("Type")),
            title,
            pointsText: text(details?.querySelector(BB_SELECTORS.points)) || void 0,
            details: text(details?.querySelector(BB_SELECTORS.details)) || void 0,
            assignedText: text(cell("Assign")),
            dueText: text(cell("Due")),
            statusText: text(cell("Status")?.querySelector(BB_SELECTORS.status)),
            scoreText: text(cell("Status")?.querySelector(BB_SELECTORS.score)) || void 0
          });
        });
      }
      if (kind === "schedule") {
        r.querySelectorAll(BB_SELECTORS.calendarItems).forEach((li) => {
          const day = li.closest("[data-date]")?.getAttribute("data-date") ?? "";
          out.assignments.push({
            externalId: li.getAttribute("data-assignment-id") ?? void 0,
            courseExternalId: li.getAttribute("data-section-id") ?? void 0,
            courseName: text(li.querySelector(".wbp-cal-class")),
            typeText: li.getAttribute("data-type") ?? void 0,
            title: text(li.querySelector(".wbp-cal-title")),
            dueText: day
          });
        });
        r.querySelectorAll(BB_SELECTORS.calendarEvents).forEach((li) => {
          out.events.push({
            externalId: li.getAttribute("data-event-id") ?? void 0,
            title: text(li.querySelector(".wbp-cal-title")),
            dateText: li.closest("[data-date]")?.getAttribute("data-date") ?? ""
          });
        });
      }
      if (kind === "progress") {
        const term = text(r.querySelector(BB_SELECTORS.term));
        r.querySelectorAll(BB_SELECTORS.progressRows).forEach((row) => {
          out.grades.push({
            courseExternalId: row.getAttribute("data-section-id") ?? void 0,
            courseName: text(row.querySelector(".wbp-class")),
            teacher: text(row.querySelector(BB_SELECTORS.teacher)).split(" \xB7 ")[0] || void 0,
            percentText: text(row.querySelector(".wbp-grade")),
            letter: text(row.querySelector(".wbp-letter")) || void 0,
            term
          });
        });
      }
      if (kind === "class") {
        const page = r.querySelector(BB_SELECTORS.classPage);
        const courseName = text(page?.querySelector(BB_SELECTORS.className));
        const teacher = text(page?.querySelector(BB_SELECTORS.teacher));
        r.querySelectorAll(BB_SELECTORS.bulletins).forEach((b) => {
          out.announcements.push({
            externalId: b.getAttribute("data-bulletin-id") ?? void 0,
            courseName,
            teacher,
            title: text(b.querySelector("h4")),
            body: text(b.querySelector("p")),
            postedText: b.querySelector("time")?.getAttribute("datetime") ?? text(b.querySelector("time"))
          });
        });
      }
      if (kind === "unknown") out.warnings.push("This Blackbaud page has no academic data ClassPano reads yet. Open Assignment Center, Schedule, Progress or a class page.");
      return out;
    }
  };

  // src/core/adapters/canvas.ts
  var canvasAdapter = {
    id: "canvas",
    name: "Canvas LMS",
    version: "0.1.0-preview",
    status: "preview",
    matches(ctx) {
      try {
        const host = new URL(ctx.url).hostname;
        return /\.instructure\.com$/i.test(host) || !!ctx.root.querySelector("#application.ic-app");
      } catch {
        return false;
      }
    },
    detectPage() {
      return "assignments";
    },
    async extract(ctx) {
      const out = emptyResult("assignments");
      if (!ctx.fetchJson) {
        out.warnings.push("Canvas reads the planner feed in the student's session; no fetch available here.");
        return out;
      }
      const items = await ctx.fetchJson("/api/v1/planner/items?per_page=100");
      for (const it of items) {
        if (!["assignment", "quiz", "discussion_topic"].includes(it.plannable_type)) continue;
        const s = it.submissions || void 0;
        out.assignments.push({
          externalId: String(it.plannable_id),
          courseExternalId: it.course_id != null ? String(it.course_id) : void 0,
          courseName: it.context_name ?? "Canvas course",
          typeText: it.plannable_type === "quiz" ? "Quiz" : "Homework",
          title: it.plannable?.title ?? "Untitled",
          dueText: (it.plannable?.due_at ?? it.plannable_date ?? "").slice(0, 10),
          assignedText: it.plannable?.created_at?.slice(0, 10),
          pointsText: it.plannable?.points_possible != null ? `${it.plannable.points_possible} pts` : void 0,
          statusText: s?.missing ? "Missing" : s?.graded ? "Graded" : s?.submitted ? "Completed" : "To Do"
        });
      }
      return out;
    }
  };

  // src/core/adapters/registry.ts
  var ADAPTERS = [blackbaudAdapter, canvasAdapter];
  function pickAdapter(ctx) {
    return ADAPTERS.find((a) => a.matches(ctx)) ?? null;
  }

  // extension/src/content.ts
  globalThis.__classpanoExtract = async () => {
    const ctx = {
      url: location.href,
      root: document,
      fetchJson: (path) => fetch(path, { credentials: "include", headers: { accept: "application/json" } }).then((r) => r.json())
    };
    const adapter = pickAdapter(ctx);
    if (!adapter) {
      const selection = window.getSelection()?.toString().trim() ?? "";
      return { supported: false, url: location.href, title: document.title, text: (selection || document.body.innerText).slice(0, 2e4), fromSelection: !!selection };
    }
    const raw = await adapter.extract(ctx);
    return { supported: true, url: location.href, adapter: { id: adapter.id, version: adapter.version, name: adapter.name }, raw };
  };
})();
