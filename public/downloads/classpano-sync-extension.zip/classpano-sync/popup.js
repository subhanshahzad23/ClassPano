"use strict";
(() => {
  // src/core/hash.ts
  function fnv1a(s, seed) {
    let h = seed >>> 0;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }
  function hash64(s) {
    return fnv1a(s, 2166136261).toString(16).padStart(8, "0") + fnv1a(s, 2166136261 ^ 1540483477).toString(16).padStart(8, "0");
  }
  function canonical(v) {
    if (v === null || typeof v !== "object") return JSON.stringify(v ?? null);
    if (Array.isArray(v)) return `[${v.map(canonical).join(",")}]`;
    const o = v;
    return `{${Object.keys(o).filter((k) => o[k] !== void 0).sort().map((k) => `${JSON.stringify(k)}:${canonical(o[k])}`).join(",")}}`;
  }
  function fingerprint(fields) {
    return hash64(canonical(fields));
  }
  function stableId(prefix, identityKey) {
    return `${prefix}_${hash64(identityKey).slice(0, 12)}`;
  }

  // src/core/normalize.ts
  function parseDate(input) {
    if (!input) return void 0;
    const s = input.trim();
    let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return `${m[1]}-${m[2]}-${m[3]}`;
    m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (m) return `${m[3]}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`;
    const t = Date.parse(s);
    if (!Number.isNaN(t)) return new Date(t).toISOString().slice(0, 10);
    return void 0;
  }
  function cleanCourseName(name) {
    return name.replace(/\s+-\s+\d+\s*(\([A-Z0-9]+\))?\s*$/i, "").replace(/\s+/g, " ").trim();
  }
  function courseKey(name) {
    return cleanCourseName(name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  }
  var KIND_MAP = [
    [/test|exam|assessment/i, "test"],
    [/quiz|check/i, "quiz"],
    [/project|presentation/i, "project"],
    [/lab/i, "lab"],
    [/essay|paper|writing|narrative/i, "essay"],
    [/read/i, "reading"],
    [/homework|hw|worksheet|classwork|assignment/i, "homework"]
  ];
  function toKind(typeText, title) {
    for (const [re, k] of KIND_MAP) if (typeText && re.test(typeText)) return k;
    for (const [re, k] of KIND_MAP) if (title && re.test(title)) return k;
    return "other";
  }
  function toStatus(statusText) {
    const s = (statusText ?? "").toLowerCase();
    if (s.includes("missing")) return "missing";
    if (s.includes("overdue") || s.includes("late")) return "overdue";
    if (s.includes("graded")) return "graded";
    if (s.includes("complete") || s.includes("submitted") || s.includes("turned in")) return "submitted";
    if (s.includes("progress")) return "in_progress";
    if (s.includes("excused")) return "excused";
    return "to_do";
  }
  var num = (s) => {
    const m = s?.match(/-?\d+(\.\d+)?/);
    return m ? Number(m[0]) : void 0;
  };
  function origin(url) {
    try {
      return new URL(url).hostname;
    } catch {
      return "unknown";
    }
  }
  function normalizeTitle(t) {
    return t.toLowerCase().replace(/[–—]/g, "-").replace(/[^a-z0-9.\s-]/g, " ").replace(/\s+/g, " ").trim();
  }
  function sourceRef(ctx, pageKind, externalId) {
    return { platform: ctx.platform, adapter: ctx.adapter, method: "adapter", origin: origin(ctx.url), url: ctx.url, pageKind, externalId, capturedAt: ctx.now };
  }
  function assignmentToItem(a, pageKind, ctx) {
    const host = origin(ctx.url);
    const course = cleanCourseName(a.courseName);
    const ck = courseKey(a.courseName);
    const identityKey = a.externalId ? `${ctx.platform}:${host}:assignment:${a.externalId}` : `${ctx.platform}:${host}:${ck}:${normalizeTitle(a.title)}:${parseDate(a.assignedText) ?? ""}`;
    const score = num(a.scoreText);
    const points = num(a.pointsText) ?? (a.scoreText?.includes("/") ? num(a.scoreText.split("/")[1]) : void 0);
    const base = {
      kind: toKind(a.typeText, a.title),
      title: a.title.trim(),
      courseName: course,
      courseKey: ck,
      teacher: a.teacher,
      assignedAt: parseDate(a.assignedText),
      dueAt: parseDate(a.dueText),
      status: toStatus(a.statusText),
      pointsPossible: points,
      score,
      details: a.details
    };
    return {
      id: stableId("itm", identityKey),
      identityKey,
      identityStrategy: a.externalId ? "external_id" : "composite",
      aliases: [],
      ...base,
      verified: true,
      source: sourceRef(ctx, pageKind, a.externalId),
      fingerprint: fingerprint(base),
      firstSeenAt: ctx.now,
      lastSeenAt: ctx.now,
      history: []
    };
  }
  function normalizeExtraction(res, ctx) {
    const host = origin(ctx.url);
    const items = res.assignments.map((a) => assignmentToItem(a, res.pageKind, ctx));
    for (const e of res.events) {
      const identityKey = e.externalId ? `${ctx.platform}:${host}:event:${e.externalId}` : `${ctx.platform}:${host}:event:${normalizeTitle(e.title)}:${parseDate(e.dateText)}`;
      const base = { kind: "event", title: e.title, courseName: "School-wide", courseKey: "school", dueAt: parseDate(e.dateText), status: "info" };
      items.push({
        id: stableId("itm", identityKey),
        identityKey,
        identityStrategy: e.externalId ? "external_id" : "composite",
        aliases: [],
        ...base,
        verified: true,
        source: sourceRef(ctx, res.pageKind, e.externalId),
        fingerprint: fingerprint(base),
        firstSeenAt: ctx.now,
        lastSeenAt: ctx.now,
        history: []
      });
    }
    for (const n of res.announcements) {
      const ck = courseKey(n.courseName);
      const identityKey = n.externalId ? `${ctx.platform}:${host}:bulletin:${n.externalId}` : `${ctx.platform}:${host}:bulletin:${ck}:${normalizeTitle(n.title)}`;
      const base = { kind: "announcement", title: n.title, courseName: cleanCourseName(n.courseName), courseKey: ck, teacher: n.teacher, assignedAt: parseDate(n.postedText), status: "info", details: n.body };
      items.push({
        id: stableId("itm", identityKey),
        identityKey,
        identityStrategy: n.externalId ? "external_id" : "composite",
        aliases: [],
        ...base,
        verified: true,
        source: sourceRef(ctx, res.pageKind, n.externalId),
        fingerprint: fingerprint(base),
        firstSeenAt: ctx.now,
        lastSeenAt: ctx.now,
        history: []
      });
    }
    const grades = res.grades.map((g) => {
      const ck = courseKey(g.courseName);
      const key = `${ctx.platform}:${host}:grade:${g.courseExternalId ?? ck}:${g.term ?? ""}`;
      const percent = num(g.percentText) ?? 0;
      return {
        id: stableId("grd", key),
        courseKey: ck,
        courseName: cleanCourseName(g.courseName),
        teacher: g.teacher,
        term: g.term ?? "Current term",
        percent,
        letter: g.letter,
        source: sourceRef(ctx, res.pageKind, g.courseExternalId),
        fingerprint: fingerprint({ percent, letter: g.letter }),
        firstSeenAt: ctx.now,
        lastSeenAt: ctx.now,
        history: []
      };
    });
    return { items, grades, partial: res.pageKind === "schedule" };
  }

  // src/core/ai-capture.ts
  var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var WEEKDAYS = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
  function findDate(line, refIso) {
    const ref = /* @__PURE__ */ new Date(refIso + "T12:00:00Z");
    const year = ref.getUTCFullYear();
    let m = line.match(/\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/);
    if (m) {
      const y = m[3] ? m[3].length === 2 ? 2e3 + Number(m[3]) : Number(m[3]) : year;
      return { iso: `${y}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`, raw: m[0], explicit: true };
    }
    m = line.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s*(\d{4}))?/i);
    if (m) {
      const mi = MONTHS.indexOf(m[1].slice(0, 3).toLowerCase());
      const y = m[3] ? Number(m[3]) : year;
      return { iso: `${y}-${String(mi + 1).padStart(2, "0")}-${m[2].padStart(2, "0")}`, raw: m[0], explicit: true };
    }
    m = line.match(/\b(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/i);
    if (m) {
      const target = WEEKDAYS.indexOf(m[1].toLowerCase());
      const diff = (target - ref.getUTCDay() + 7) % 7 || 7;
      const d = new Date(ref.getTime() + diff * 864e5);
      return { iso: d.toISOString().slice(0, 10), raw: m[0], explicit: false };
    }
    return null;
  }
  var NOT_WORK = /office hours|lunch|no school|welcome|bring snacks|club meets|last updated|^week of|agenda\s*$/i;
  var EVENT = /dismissal|assembly|picture|field trip(?! permission)|conference|no school/i;
  var OPTIONAL = /optional|extra credit|bonus/i;
  var ACTIVITY = /\b(start|begin|notes in class|introduce|review in class)\b/i;
  function cleanTitle(line, date) {
    let t = line;
    if (date) t = t.replace(date.raw, " ");
    if (date?.explicit) t = t.replace(/\b(by|on|due)?\s*(mon|tues|wednes|thurs|fri|satur|sun)day\b,?/gi, " ");
    t = t.replace(/^\s*(mon|tue|wed|thu|fri|sat|sun)[a-z]*\.?\s*/i, "").replace(/\s+(due|by|on)\s*[,.]?\s*$/i, "").replace(/\s+(due|by|on)\s*([.!])/i, "$2").replace(/^[\s:–—-]+/, "").replace(/\s*[–—-]\s*$/, "").replace(/\s+/g, " ").trim();
    const [head, ...rest] = t.split(/(?<=[.!])\s+/);
    let title = head.replace(/[.!]$/, "").replace(/\s+\bdue\b(?=\s*(\(|$))/i, "").trim();
    if (title.length > 80) title = title.slice(0, 77).trimEnd() + "\u2026";
    return { title: title.charAt(0).toUpperCase() + title.slice(1), details: rest.join(" ").trim() || void 0 };
  }
  function extractCandidates(text, opts) {
    const lines = text.split(/\n|(?<=\.)\s+(?=[A-Z][a-z]{2} \d)/).map((l) => l.replace(/\s+/g, " ").trim()).filter((l) => l.length > 6);
    const candidates = [];
    const ignored = [];
    lines.forEach((line, i) => {
      const date = findDate(line, opts.refDate);
      if (!date || NOT_WORK.test(line)) {
        if (/\d|due|test|quiz/i.test(line)) ignored.push(line);
        return;
      }
      const isEvent = EVENT.test(line);
      const { title, details } = cleanTitle(line, date);
      if (!title || title.length < 4) {
        ignored.push(line);
        return;
      }
      const kind = isEvent ? "event" : toKind(void 0, line);
      const flags = [];
      let confidence = 0.62;
      if (date.explicit) confidence += 0.14;
      else flags.push(`Date inferred from \u201C${date.raw}\u201D`);
      if (kind !== "other") confidence += 0.12;
      if (/\bdue\b/i.test(line)) confidence += 0.06;
      if (OPTIONAL.test(line)) {
        confidence -= 0.14;
        flags.push("Marked optional");
      }
      if (ACTIVITY.test(line) && !/\bread|worksheet|due|complete\b/i.test(line)) {
        confidence -= 0.22;
        flags.push("Looks like a class activity, not homework");
      }
      confidence = Math.max(0.2, Math.min(0.97, Number(confidence.toFixed(2))));
      candidates.push({
        tempId: `cand_${i}`,
        title,
        kind,
        courseName: isEvent ? "School-wide" : opts.courseHint,
        dueAt: date.iso,
        details,
        evidence: line,
        confidence,
        flags,
        suggested: confidence >= 0.6
      });
    });
    return { candidates, ignored };
  }
  function candidateToItem(c, ctx) {
    const host = (() => {
      try {
        return new URL(ctx.url).hostname;
      } catch {
        return "unknown";
      }
    })();
    const ck = c.kind === "event" ? "school" : courseKey(c.courseName);
    const identityKey = `generic:${host}:${ck}:${normalizeTitle(c.title)}`;
    const base = {
      kind: c.kind,
      title: c.title,
      courseName: c.kind === "event" ? "School-wide" : cleanCourseName(c.courseName),
      courseKey: ck,
      dueAt: c.dueAt,
      status: c.kind === "event" ? "info" : "to_do",
      details: c.details
    };
    return {
      id: stableId("itm", identityKey),
      identityKey,
      identityStrategy: "composite",
      aliases: [],
      ...base,
      verified: false,
      confidence: c.confidence,
      source: { platform: "generic", adapter: "ai-capture@0.2.0", method: "ai_capture", origin: host, url: ctx.url, pageKind: "unknown", capturedAt: ctx.now },
      fingerprint: fingerprint(base),
      firstSeenAt: ctx.now,
      lastSeenAt: ctx.now,
      history: []
    };
  }

  // src/core/similarity.ts
  var STOP = /* @__PURE__ */ new Set(["the", "a", "an", "and", "of", "on", "in", "for", "to", "with", "due", "complete", "finish", "your"]);
  function tokens(title) {
    return normalizeTitle(title).replace(/[.-]/g, " ").split(" ").filter((t) => t && !STOP.has(t));
  }
  function titleSimilarity(a, b) {
    const A = tokens(a);
    const B = new Set(tokens(b));
    if (!A.length || !B.size) return 0;
    const setA = new Set(A);
    let shared = 0;
    setA.forEach((t) => B.has(t) && shared++);
    return 2 * shared / (setA.size + B.size);
  }

  // src/core/schema.ts
  var SCHEMA_VERSION = "cp.academic.v1";
  var TRACKED_FIELDS = ["title", "kind", "dueAt", "status", "score", "pointsPossible", "details", "teacher"];

  // src/core/merge.ts
  var val = (v) => v === void 0 ? null : v;
  var PARTIAL_FIELDS = ["title", "dueAt"];
  var FUZZY_THRESHOLD = 0.6;
  function findFuzzyMatch(items, incoming) {
    let best = null;
    for (const it of Object.values(items)) {
      if (it.id === incoming.id) continue;
      if (it.courseKey !== incoming.courseKey) continue;
      const sim = titleSimilarity(it.title, incoming.title);
      const sameDue = !!it.dueAt && it.dueAt === incoming.dueAt;
      const score = sim * 0.7 + (sameDue ? 0.3 : 0);
      if (score >= FUZZY_THRESHOLD && sim >= 0.5 && (!best || score > best.score)) best = { match: it, score };
    }
    return best;
  }
  function mergeNormalized(state, norm, meta) {
    const items = { ...state.items };
    const grades = { ...state.grades };
    const changes = [];
    const counts = { found: norm.items.length + norm.grades.length, created: 0, updated: 0, unchanged: 0, duplicatesPrevented: 0 };
    const seenThisBatch = /* @__PURE__ */ new Set();
    for (const inc of norm.items) {
      if (seenThisBatch.has(inc.id)) {
        counts.duplicatesPrevented++;
        continue;
      }
      seenThisBatch.add(inc.id);
      const existing = items[inc.id] ?? Object.values(items).find((i) => i.aliases.includes(inc.identityKey));
      if (!existing && inc.identityStrategy === "composite") {
        const fuzzy = findFuzzyMatch(items, inc);
        if (fuzzy) {
          const m = fuzzy.match;
          const note = inc.details && !m.details?.includes(inc.details) ? `${inc.source.origin}: \u201C${inc.details}\u201D` : void 0;
          items[m.id] = {
            ...m,
            aliases: [...m.aliases, inc.identityKey],
            notes: note ? [...m.notes ?? [], note] : m.notes,
            lastSeenAt: meta.now
          };
          counts.duplicatesPrevented++;
          changes.push({ recordId: m.id, title: m.title, type: "merged", fields: [{ field: "match", from: inc.title, to: `${Math.round(fuzzy.score * 100)}% match` }] });
          continue;
        }
      }
      if (!existing) {
        items[inc.id] = { ...inc, firstSeenAt: meta.now, lastSeenAt: meta.now };
        counts.created++;
        changes.push({ recordId: inc.id, title: inc.title, type: "created" });
        continue;
      }
      if (existing.verified && !inc.verified) {
        items[existing.id] = { ...existing, lastSeenAt: meta.now };
        counts.duplicatesPrevented++;
        continue;
      }
      const fields = norm.partial ? PARTIAL_FIELDS : TRACKED_FIELDS;
      const diffs = [];
      for (const f of fields) {
        const a = val(existing[f]);
        const b = val(inc[f]);
        if (norm.partial && b === null) continue;
        if (a !== b) diffs.push({ field: f, from: a, to: b });
      }
      if (!diffs.length) {
        items[existing.id] = { ...existing, lastSeenAt: meta.now };
        if (existing.source.pageKind !== inc.source.pageKind) counts.duplicatesPrevented++;
        else counts.unchanged++;
        continue;
      }
      const history = diffs.map((d) => ({ at: meta.now, syncId: meta.syncId, field: d.field, from: d.from, to: d.to }));
      const patch = {};
      for (const d of diffs) patch[d.field] = d.to ?? void 0;
      items[existing.id] = {
        ...existing,
        ...patch,
        fingerprint: norm.partial ? existing.fingerprint : inc.fingerprint,
        source: norm.partial ? existing.source : inc.source,
        lastSeenAt: meta.now,
        history: [...existing.history, ...history]
      };
      counts.updated++;
      changes.push({ recordId: existing.id, title: existing.title, type: "updated", fields: diffs });
    }
    for (const g of norm.grades) {
      const existing = grades[g.id];
      if (!existing) {
        grades[g.id] = g;
        counts.created++;
        changes.push({ recordId: g.id, title: `${g.courseName} grade`, type: "created" });
        continue;
      }
      if (existing.fingerprint === g.fingerprint) {
        grades[g.id] = { ...existing, lastSeenAt: meta.now };
        counts.unchanged++;
        continue;
      }
      const diffs = [];
      if (existing.percent !== g.percent) diffs.push({ field: "percent", from: existing.percent, to: g.percent });
      if ((existing.letter ?? null) !== (g.letter ?? null)) diffs.push({ field: "letter", from: existing.letter ?? null, to: g.letter ?? null });
      grades[g.id] = {
        ...existing,
        percent: g.percent,
        letter: g.letter,
        fingerprint: g.fingerprint,
        source: g.source,
        lastSeenAt: meta.now,
        history: [...existing.history, ...diffs.map((d) => ({ at: meta.now, syncId: meta.syncId, field: d.field, from: d.from, to: d.to }))]
      };
      counts.updated++;
      changes.push({ recordId: g.id, title: `${g.courseName} grade`, type: "updated", fields: diffs });
    }
    const run = {
      id: meta.syncId,
      at: meta.now,
      platform: meta.platform,
      adapter: meta.adapter,
      method: meta.method,
      pageKind: meta.pageKind,
      url: meta.url,
      durationMs: Math.max(1, Math.round(performance.now() - meta.startedAt)),
      counts,
      changes,
      warnings: meta.warnings ?? []
    };
    return { items, grades, run };
  }

  // extension/src/popup.ts
  var app = document.getElementById("app");
  var esc = (s) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  async function load() {
    const { state } = await chrome.storage.local.get("state");
    return state ?? { items: {}, grades: {}, syncs: [] };
  }
  async function save(s) {
    await chrome.storage.local.set({ state: s });
    updateCount(s);
  }
  function updateCount(s) {
    document.getElementById("count").textContent = `${Object.keys(s.items).length + Object.keys(s.grades).length} records`;
  }
  async function activeTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
  }
  async function extract(tabId) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    const [res] = await chrome.scripting.executeScript({ target: { tabId }, func: () => globalThis.__classpanoExtract() });
    return res.result;
  }
  function consent() {
    app.innerHTML = `
    <p class="eyebrow">First time</p>
    <h1>Let ClassPano read pages when you press Sync?</h1>
    <ul class="rules">
      <li><i class="ok">\u2713</i>Reads assignments, due dates, classes and grades on the page you choose.</li>
      <li><i class="ok">\u2713</i>Only when you press Sync. Nothing runs in the background.</li>
      <li><i class="no">\u2715</i>Never sees or stores your school password.</li>
      <li><i class="no">\u2715</i>Never submits or changes anything on the site.</li>
    </ul>
    <div class="box muted">Permissions: activeTab, scripting, storage. No \u201Cread all websites\u201D.</div>
    <button class="primary" id="allow">Allow</button>
    <div class="row"><button class="ghost" id="later">Not now</button></div>`;
    document.getElementById("allow").onclick = async () => {
      await chrome.storage.local.set({ consent: true });
      void main();
    };
    document.getElementById("later").onclick = () => window.close();
  }
  function result(run, adapterName) {
    const updated = run.changes.filter((c) => c.type !== "created");
    return `
    <p class="eyebrow">${esc(adapterName)} \xB7 ${esc(run.pageKind)}</p>
    <div class="tiles">
      <div class="${run.counts.created ? "hi" : ""}"><b>${run.counts.created}</b><span>New</span></div>
      <div class="${run.counts.updated ? "hi" : ""}"><b>${run.counts.updated}</b><span>Updated</span></div>
      <div><b>${run.counts.unchanged}</b><span>Same</span></div>
      <div><b>${run.counts.duplicatesPrevented}</b><span>Dupes</span></div>
    </div>
    ${updated.length ? `<p class="eyebrow" style="margin:8px 0 6px">What changed</p><ul class="changes">${updated.map((c) => `<li><b>${esc(c.title)}</b>${(c.fields ?? []).map((f) => `${esc(f.field)}: ${esc(String(f.from ?? "\u2014"))} \u2192 ${esc(String(f.to ?? "\u2014"))}`).join("<br>")}</li>`).join("")}</ul>` : ""}`;
  }
  function exportJson(s) {
    const payload = { schema: SCHEMA_VERSION, exportedAt: (/* @__PURE__ */ new Date()).toISOString(), student: "ClassPano user", items: Object.values(s.items), grades: Object.values(s.grades), syncs: s.syncs };
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
    a.download = "classpano-export.json";
    a.click();
  }
  var TOOLBAR = `<div class="row"><button class="outline" id="export">Export JSON</button><button class="ghost" id="clear">Clear data</button></div>`;
  function bindToolbar(s) {
    document.getElementById("export").onclick = () => exportJson(s);
    document.getElementById("clear").onclick = async () => {
      await save({ items: {}, grades: {}, syncs: [] });
      void main();
    };
  }
  function review(ex, state) {
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const { candidates } = extractCandidates(ex.text, { courseHint: ex.title.split(/[|·–-]/)[0].trim() || "My class", refDate: today });
    if (!candidates.length) {
      app.innerHTML = `<div class="box warn">No tasks or dates found${ex.fromSelection ? " in your selection" : " on this page"}.</div><button class="outline" id="back">Back</button>`;
      document.getElementById("back").onclick = () => void main();
      return;
    }
    app.innerHTML = `<p class="eyebrow">Review before saving</p><p class="muted" style="margin:6px 0 10px">Uncheck anything that isn't real work. Saved items are marked AI-extracted, not verified. (Prototype: a local extractor stands in for the LLM.)</p>
    ${candidates.map(
      (c, i) => `<label class="cand"><input type="checkbox" data-i="${i}" ${c.suggested ? "checked" : ""}/><span><b>${esc(c.title)}</b><small>${esc(c.kind)} \xB7 due ${esc(c.dueAt ?? "\u2014")} \xB7 ${Math.round(c.confidence * 100)}% confident${c.flags.length ? " \xB7 " + esc(c.flags.join(", ")) : ""}</small></span></label>`
    ).join("")}
    <button class="primary" id="save">Save checked items</button><div class="row"><button class="ghost" id="back">Cancel</button></div>`;
    document.getElementById("back").onclick = () => void main();
    document.getElementById("save").onclick = async () => {
      const keep = [];
      app.querySelectorAll("input[data-i]").forEach((el) => el.checked && keep.push(candidates[Number(el.dataset.i)]));
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const merged = mergeNormalized(
        state,
        { items: keep.map((c) => candidateToItem(c, { url: ex.url, now })), grades: [], partial: false },
        { syncId: `sync_${Date.now().toString(36)}`, now, startedAt: performance.now(), pageKind: "unknown", platform: "generic", adapter: "ai-capture@0.2.0", url: ex.url, method: "ai_capture" }
      );
      const next = { items: merged.items, grades: merged.grades, syncs: [merged.run, ...state.syncs].slice(0, 50) };
      await save(next);
      app.innerHTML = result(merged.run, "AI-assisted capture") + TOOLBAR;
      bindToolbar(next);
    };
  }
  async function main() {
    const tab = await activeTab();
    const host = (() => {
      try {
        return new URL(tab?.url ?? "").hostname;
      } catch {
        return "";
      }
    })();
    document.getElementById("host").textContent = host || "No page";
    const state = await load();
    updateCount(state);
    const { consent: ok } = await chrome.storage.local.get("consent");
    if (!ok) return consent();
    if (!tab?.id || !/^https?:/.test(tab.url ?? "")) {
      app.innerHTML = `<div class="box warn">Open your school portal in this tab, then click ClassPano Sync again.</div>`;
      return;
    }
    app.innerHTML = `<div class="box"><b>Ready on ${esc(host)}</b><br><span class="muted">Press Sync to capture what's on this page.</span></div>
    <button class="primary" id="sync">Sync this page</button>${TOOLBAR}`;
    bindToolbar(state);
    document.getElementById("sync").onclick = async () => {
      const btn = document.getElementById("sync");
      btn.disabled = true;
      btn.textContent = "Reading this page\u2026";
      let ex;
      try {
        ex = await extract(tab.id);
      } catch (e) {
        app.innerHTML = `<div class="box warn">Chrome didn't allow reading this page (${esc(String(e))}).</div>`;
        return;
      }
      if (!ex.supported) {
        app.innerHTML = `<div class="box warn"><b>No ClassPano module for this site.</b><br>Capture ${ex.fromSelection ? "your selected text" : "this page"} with AI and review every item before it's saved?</div>
        <button class="dark" id="ai">Capture with AI (review first)</button><div class="row"><button class="ghost" id="back">Cancel</button></div>`;
        document.getElementById("ai").onclick = () => review(ex, state);
        document.getElementById("back").onclick = () => void main();
        return;
      }
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const id = `${ex.adapter.id}@${ex.adapter.version}`;
      const norm = normalizeExtraction(ex.raw, { platform: ex.adapter.id, adapter: id, url: ex.url, now });
      const merged = mergeNormalized(state, norm, { syncId: `sync_${Date.now().toString(36)}`, now, startedAt: performance.now(), pageKind: ex.raw.pageKind, platform: ex.adapter.id, adapter: id, url: ex.url, method: "adapter", warnings: ex.raw.warnings });
      const next = { items: merged.items, grades: merged.grades, syncs: [merged.run, ...state.syncs].slice(0, 50) };
      await save(next);
      app.innerHTML = result(merged.run, ex.adapter.name) + `<button class="primary" id="again" style="margin-top:6px">Sync again</button>` + TOOLBAR;
      document.getElementById("again").onclick = () => void main();
      bindToolbar(next);
    };
  }
  void main();
})();
